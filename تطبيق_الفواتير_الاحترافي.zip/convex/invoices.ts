import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

// إضافة فاتورة جديدة
export const createInvoice = mutation({
  args: {
    customerName: v.string(),
    amount: v.number(),
    notes: v.optional(v.string()),
    attachmentId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("يجب تسجيل الدخول أولاً");
    }

    // إنشاء رقم فاتورة تلقائي
    const invoiceCount = await ctx.db
      .query("invoices")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
    
    const invoiceNumber = `INV-${String(invoiceCount.length + 1).padStart(4, '0')}`;
    const currentDate = new Date().toISOString().split('T')[0];

    return await ctx.db.insert("invoices", {
      invoiceNumber,
      customerName: args.customerName,
      amount: args.amount,
      date: currentDate,
      notes: args.notes,
      attachmentId: args.attachmentId,
      userId,
    });
  },
});

// جلب جميع الفواتير للمستخدم
export const getAllInvoices = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const invoices = await ctx.db
      .query("invoices")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();

    return Promise.all(
      invoices.map(async (invoice) => ({
        ...invoice,
        attachmentUrl: invoice.attachmentId
          ? await ctx.storage.getUrl(invoice.attachmentId)
          : null,
      }))
    );
  },
});

// جلب فواتير بتاريخ محدد
export const getInvoicesByDate = query({
  args: { date: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const invoices = await ctx.db
      .query("invoices")
      .withIndex("by_user_and_date", (q) => 
        q.eq("userId", userId).eq("date", args.date)
      )
      .collect();

    return Promise.all(
      invoices.map(async (invoice) => ({
        ...invoice,
        attachmentUrl: invoice.attachmentId
          ? await ctx.storage.getUrl(invoice.attachmentId)
          : null,
      }))
    );
  },
});

// جلب فواتير شهر محدد
export const getInvoicesByMonth = query({
  args: { year: v.number(), month: v.number() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const invoices = await ctx.db
      .query("invoices")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const filteredInvoices = invoices.filter(invoice => {
      const invoiceDate = new Date(invoice.date);
      return invoiceDate.getFullYear() === args.year && 
             invoiceDate.getMonth() === args.month - 1;
    });

    return Promise.all(
      filteredInvoices.map(async (invoice) => ({
        ...invoice,
        attachmentUrl: invoice.attachmentId
          ? await ctx.storage.getUrl(invoice.attachmentId)
          : null,
      }))
    );
  },
});

// جلب فواتير خلال فترة محددة
export const getInvoicesByDateRange = query({
  args: { startDate: v.string(), endDate: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const invoices = await ctx.db
      .query("invoices")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const filteredInvoices = invoices.filter(invoice => {
      return invoice.date >= args.startDate && invoice.date <= args.endDate;
    });

    return Promise.all(
      filteredInvoices.map(async (invoice) => ({
        ...invoice,
        attachmentUrl: invoice.attachmentId
          ? await ctx.storage.getUrl(invoice.attachmentId)
          : null,
      }))
    );
  },
});

// البحث في الفواتير
export const searchInvoices = query({
  args: { searchTerm: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    // البحث بالاسم
    const nameResults = await ctx.db
      .query("invoices")
      .withSearchIndex("search_invoices", (q) =>
        q.search("customerName", args.searchTerm).eq("userId", userId)
      )
      .collect();

    // البحث برقم الفاتورة أو المبلغ
    const allInvoices = await ctx.db
      .query("invoices")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const otherResults = allInvoices.filter(invoice => 
      invoice.invoiceNumber.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
      invoice.amount.toString().includes(args.searchTerm) ||
      invoice.date.includes(args.searchTerm)
    );

    // دمج النتائج وإزالة المكررات
    const combinedResults = [...nameResults, ...otherResults];
    const uniqueResults = combinedResults.filter((invoice, index, self) =>
      index === self.findIndex(i => i._id === invoice._id)
    );

    return Promise.all(
      uniqueResults.map(async (invoice) => ({
        ...invoice,
        attachmentUrl: invoice.attachmentId
          ? await ctx.storage.getUrl(invoice.attachmentId)
          : null,
      }))
    );
  },
});

// تحديث فاتورة
export const updateInvoice = mutation({
  args: {
    id: v.id("invoices"),
    customerName: v.string(),
    amount: v.number(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("يجب تسجيل الدخول أولاً");
    }

    const invoice = await ctx.db.get(args.id);
    if (!invoice || invoice.userId !== userId) {
      throw new Error("الفاتورة غير موجودة");
    }

    await ctx.db.patch(args.id, {
      customerName: args.customerName,
      amount: args.amount,
      notes: args.notes,
    });
  },
});

// حذف فاتورة
export const deleteInvoice = mutation({
  args: { id: v.id("invoices") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("يجب تسجيل الدخول أولاً");
    }

    const invoice = await ctx.db.get(args.id);
    if (!invoice || invoice.userId !== userId) {
      throw new Error("الفاتورة غير موجودة");
    }

    await ctx.db.delete(args.id);
  },
});

// إحصائيات شهرية
export const getMonthlyStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return { monthlyTotals: [], topCustomer: null, highestInvoice: null };
    }

    const invoices = await ctx.db
      .query("invoices")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    // حساب المجاميع الشهرية
    const monthlyTotals: { [key: string]: number } = {};
    const customerTotals: { [key: string]: number } = {};

    let highestInvoice = invoices[0];

    invoices.forEach(invoice => {
      const date = new Date(invoice.date);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      monthlyTotals[monthKey] = (monthlyTotals[monthKey] || 0) + invoice.amount;
      customerTotals[invoice.customerName] = (customerTotals[invoice.customerName] || 0) + invoice.amount;

      if (!highestInvoice || invoice.amount > highestInvoice.amount) {
        highestInvoice = invoice;
      }
    });

    // العثور على أعلى عميل
    const topCustomer = Object.entries(customerTotals).reduce(
      (max, [customer, total]) => 
        total > (max?.total || 0) ? { customer, total } : max,
      null as { customer: string; total: number } | null
    );

    return {
      monthlyTotals: Object.entries(monthlyTotals).map(([month, total]) => ({
        month,
        total,
      })),
      topCustomer,
      highestInvoice,
    };
  },
});

// إنشاء رابط رفع الملف
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});
