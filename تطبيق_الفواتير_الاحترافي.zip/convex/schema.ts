import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  invoices: defineTable({
    invoiceNumber: v.string(),
    customerName: v.string(),
    amount: v.number(),
    date: v.string(),
    notes: v.optional(v.string()),
    attachmentId: v.optional(v.id("_storage")),
    userId: v.id("users"),
  })
    .index("by_user", ["userId"])
    .index("by_user_and_date", ["userId", "date"])
    .index("by_user_and_customer", ["userId", "customerName"])
    .searchIndex("search_invoices", {
      searchField: "customerName",
      filterFields: ["userId"],
    }),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
