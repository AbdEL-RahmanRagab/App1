import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState } from "react";
import { InvoiceForm } from "./components/InvoiceForm";
import { InvoiceList } from "./components/InvoiceList";
import { SearchInvoices } from "./components/SearchInvoices";
import { Statistics } from "./components/Statistics";

export default function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [activeTab, setActiveTab] = useState("add");

  return (
    <div className={`min-h-screen ${darkMode ? 'dark' : ''}`}>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
        <header className="sticky top-0 z-10 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-b shadow-sm">
          <div className="px-4 py-3 flex justify-between items-center">
            <h1 className="text-xl font-bold text-gray-800 dark:text-white">
              📊 نظام الفواتير
            </h1>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setDarkMode(!darkMode)}
                className="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              >
                {darkMode ? "☀️" : "🌙"}
              </button>
              <SignOutButton />
            </div>
          </div>
        </header>

        <main className="p-4">
          <Content 
            activeTab={activeTab} 
            setActiveTab={setActiveTab}
          />
        </main>
        <Toaster />
      </div>
    </div>
  );
}

function Content({ activeTab, setActiveTab }: { 
  activeTab: string; 
  setActiveTab: (tab: string) => void;
}) {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Authenticated>
        <div className="mb-6">
          <div className="flex flex-wrap gap-2 bg-white dark:bg-gray-800 p-2 rounded-lg shadow-sm">
            {[
              { id: "add", label: "🧾 إضافة فاتورة", icon: "🧾" },
              { id: "list", label: "📂 عرض الفواتير", icon: "📂" },
              { id: "search", label: "🔍 البحث", icon: "🔍" },
              { id: "stats", label: "📊 الإحصائيات", icon: "📊" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-md font-medium transition-colors ${
                  activeTab === tab.id
                    ? "bg-blue-600 text-white"
                    : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
          {activeTab === "add" && <InvoiceForm />}
          {activeTab === "list" && <InvoiceList />}
          {activeTab === "search" && <SearchInvoices />}
          {activeTab === "stats" && <Statistics />}
        </div>
      </Authenticated>

      <Unauthenticated>
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-4">
            مرحباً بك في نظام الفواتير
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            سجل دخولك لبدء إدارة فواتيرك
          </p>
          <div className="max-w-md mx-auto">
            <SignInForm />
          </div>
        </div>
      </Unauthenticated>
    </div>
  );
}
