import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function InvoiceList() {
  const [viewMode, setViewMode] = useState("all");
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedMonth, setSelectedMonth] = useState("");
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString());
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [editingInvoice, setEditingInvoice] = useState<any>(null);
  const [editForm, setEditForm] = useState({
    customerName: "",
    amount: "",
    notes: "",
  });

  const allInvoices = useQuery(api.invoices.getAllInvoices);
  const todayInvoices = useQuery(api.invoices.getInvoicesByDate, {
    date: new Date().toISOString().split('T')[0]
  });
  const dateInvoices = useQuery(
    api.invoices.getInvoicesByDate,
    selectedDate ? { date: selectedDate } : "skip"
  );
  const monthInvoices = useQuery(
    api.invoices.getInvoicesByMonth,
    selectedMonth ? { 
      year: parseInt(selectedYear), 
      month: parseInt(selectedMonth) 
    } : "skip"
  );
  const rangeInvoices = useQuery(
    api.invoices.getInvoicesByDateRange,
    startDate && endDate ? { startDate, endDate } : "skip"
  );

  const updateInvoice = useMutation(api.invoices.updateInvoice);
  const deleteInvoice = useMutation(api.invoices.deleteInvoice);

  const getCurrentInvoices = () => {
    switch (viewMode) {
      case "today":
        return todayInvoices || [];
      case "date":
        return dateInvoices || [];
      case "month":
        return monthInvoices || [];
      case "range":
        return rangeInvoices || [];
      default:
        return allInvoices || [];
    }
  };

  const currentInvoices = getCurrentInvoices();
  const totalAmount = currentInvoices.reduce((sum, invoice) => sum + invoice.amount, 0);

  const handleEdit = (invoice: any) => {
    setEditingInvoice(invoice);
    setEditForm({
      customerName: invoice.customerName,
      amount: invoice.amount.toString(),
      notes: invoice.notes || "",
    });
  };

  const handleUpdate = async () => {
    if (!editingInvoice) return;

    try {
      await updateInvoice({
        id: editingInvoice._id,
        customerName: editForm.customerName,
        amount: parseFloat(editForm.amount),
        notes: editForm.notes || undefined,
      });
      setEditingInvoice(null);
      toast.success("تم تحديث الفاتورة بنجاح");
    } catch (error) {
      toast.error("حدث خطأ في تحديث الفاتورة");
    }
  };

  const handleDelete = async (invoiceId: string) => {
    if (confirm("هل أنت متأكد من حذف هذه الفاتورة؟")) {
      try {
        await deleteInvoice({ id: invoiceId as any });
        toast.success("تم حذف الفاتورة بنجاح");
      } catch (error) {
        toast.error("حدث خطأ في حذف الفاتورة");
      }
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6 text-center">
        📂 عرض الفواتير
      </h2>

      {/* خيارات العرض */}
      <div className="mb-6 space-y-4">
        <div className="flex flex-wrap gap-2">
          {[
            { id: "all", label: "جميع الفواتير" },
            { id: "today", label: "فواتير اليوم" },
            { id: "date", label: "تاريخ محدد" },
            { id: "month", label: "شهر محدد" },
            { id: "range", label: "فترة محددة" },
          ].map((mode) => (
            <button
              key={mode.id}
              onClick={() => setViewMode(mode.id)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                viewMode === mode.id
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>

        {/* فلاتر إضافية */}
        {viewMode === "date" && (
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
        )}

        {viewMode === "month" && (
          <div className="flex gap-2">
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="">اختر الشهر</option>
              {Array.from({ length: 12 }, (_, i) => (
                <option key={i + 1} value={i + 1}>
                  {new Date(2024, i).toLocaleDateString('ar-SA', { month: 'long' })}
                </option>
              ))}
            </select>
            <input
              type="number"
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              min="2020"
              max="2030"
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="السنة"
            />
          </div>
        )}

        {viewMode === "range" && (
          <div className="flex gap-2">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="من تاريخ"
            />
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="إلى تاريخ"
            />
          </div>
        )}
      </div>

      {/* إجمالي المبلغ */}
      <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg mb-6">
        <div className="text-center">
          <p className="text-lg font-semibold text-blue-800 dark:text-blue-200">
            💰 الإجمالي الكلي: {totalAmount.toFixed(2)} ريال
          </p>
          <p className="text-sm text-blue-600 dark:text-blue-300">
            عدد الفواتير: {currentInvoices.length}
          </p>
        </div>
      </div>

      {/* قائمة الفواتير */}
      <div className="space-y-4">
        {currentInvoices.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            📄 لا توجد فواتير لعرضها
          </div>
        ) : (
          currentInvoices.map((invoice) => (
            <div
              key={invoice._id}
              className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg border border-gray-200 dark:border-gray-600"
            >
              {editingInvoice?._id === invoice._id ? (
                <div className="space-y-3">
                  <input
                    type="text"
                    value={editForm.customerName}
                    onChange={(e) => setEditForm({ ...editForm, customerName: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    placeholder="اسم العميل"
                  />
                  <input
                    type="number"
                    step="0.01"
                    value={editForm.amount}
                    onChange={(e) => setEditForm({ ...editForm, amount: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    placeholder="المبلغ"
                  />
                  <textarea
                    value={editForm.notes}
                    onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    placeholder="ملاحظات"
                    rows={2}
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={handleUpdate}
                      className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors"
                    >
                      ✅ حفظ
                    </button>
                    <button
                      onClick={() => setEditingInvoice(null)}
                      className="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700 transition-colors"
                    >
                      ❌ إلغاء
                    </button>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-semibold text-gray-800 dark:text-white">
                        {invoice.invoiceNumber}
                      </h3>
                      <p className="text-gray-600 dark:text-gray-300">
                        👤 {invoice.customerName}
                      </p>
                    </div>
                    <div className="text-left">
                      <p className="font-bold text-green-600 dark:text-green-400">
                        {invoice.amount.toFixed(2)} ريال
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        📅 {new Date(invoice.date).toLocaleDateString('ar-SA')}
                      </p>
                    </div>
                  </div>
                  
                  {invoice.notes && (
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                      📝 {invoice.notes}
                    </p>
                  )}
                  
                  {invoice.attachmentUrl && (
                    <div className="mb-2">
                      <a
                        href={invoice.attachmentUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 dark:text-blue-400 hover:underline text-sm"
                      >
                        📎 عرض المرفق
                      </a>
                    </div>
                  )}
                  
                  <div className="flex gap-2 mt-3">
                    <button
                      onClick={() => handleEdit(invoice)}
                      className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 transition-colors"
                    >
                      ✏️ تعديل
                    </button>
                    <button
                      onClick={() => handleDelete(invoice._id)}
                      className="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700 transition-colors"
                    >
                      🗑️ حذف
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
