import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function SearchInvoices() {
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");

  // تأخير البحث لتحسين الأداء
  const handleSearch = (term: string) => {
    setSearchTerm(term);
    setTimeout(() => {
      setDebouncedSearchTerm(term);
    }, 500);
  };

  const searchResults = useQuery(
    api.invoices.searchInvoices,
    debouncedSearchTerm.trim() ? { searchTerm: debouncedSearchTerm.trim() } : "skip"
  );

  const totalAmount = searchResults?.reduce((sum, invoice) => sum + invoice.amount, 0) || 0;

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6 text-center">
        🔍 البحث في الفواتير
      </h2>

      <div className="mb-6">
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => handleSearch(e.target.value)}
            className="w-full px-4 py-3 pl-12 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            placeholder="ابحث بـ: اسم العميل، رقم الفاتورة، المبلغ، أو التاريخ..."
          />
          <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
            <span className="text-gray-400 text-xl">🔍</span>
          </div>
        </div>
        
        <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
          💡 يمكنك البحث بأي من: اسم العميل، رقم الفاتورة (مثل INV-0001)، المبلغ، أو التاريخ
        </div>
      </div>

      {debouncedSearchTerm && (
        <>
          {searchResults === undefined ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : (
            <>
              {searchResults.length > 0 && (
                <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg mb-6">
                  <div className="text-center">
                    <p className="text-lg font-semibold text-green-800 dark:text-green-200">
                      📊 نتائج البحث: {searchResults.length} فاتورة
                    </p>
                    <p className="text-sm text-green-600 dark:text-green-300">
                      💰 إجمالي المبلغ: {totalAmount.toFixed(2)} ريال
                    </p>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {searchResults.length === 0 ? (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <div className="text-6xl mb-4">🔍</div>
                    <p className="text-lg">لم يتم العثور على نتائج</p>
                    <p className="text-sm">جرب البحث بكلمات مختلفة</p>
                  </div>
                ) : (
                  searchResults.map((invoice) => (
                    <div
                      key={invoice._id}
                      className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg border border-gray-200 dark:border-gray-600 hover:shadow-md transition-shadow"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-semibold text-gray-800 dark:text-white">
                            📄 {invoice.invoiceNumber}
                          </h3>
                          <p className="text-gray-600 dark:text-gray-300">
                            👤 {invoice.customerName}
                          </p>
                        </div>
                        <div className="text-left">
                          <p className="font-bold text-green-600 dark:text-green-400">
                            {invoice.amount.toFixed(2)} ريال
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            📅 {new Date(invoice.date).toLocaleDateString('ar-SA')}
                          </p>
                        </div>
                      </div>
                      
                      {invoice.notes && (
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                          📝 {invoice.notes}
                        </p>
                      )}
                      
                      {invoice.attachmentUrl && (
                        <div className="mb-2">
                          <a
                            href={invoice.attachmentUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 dark:text-blue-400 hover:underline text-sm"
                          >
                            📎 عرض المرفق
                          </a>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </>
          )}
        </>
      )}

      {!debouncedSearchTerm && (
        <div className="text-center py-12 text-gray-500 dark:text-gray-400">
          <div className="text-6xl mb-4">🔍</div>
          <p className="text-lg">ابدأ بكتابة كلمة البحث</p>
          <p className="text-sm">يمكنك البحث بأي معلومة من الفاتورة</p>
        </div>
      )}
    </div>
  );
}
