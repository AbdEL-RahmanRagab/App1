import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function Statistics() {
  const stats = useQuery(api.invoices.getMonthlyStats);

  if (!stats) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const { monthlyTotals, topCustomer, highestInvoice } = stats;

  // حساب إجمالي المبيعات
  const totalSales = monthlyTotals.reduce((sum, month) => sum + month.total, 0);

  // ترتيب الأشهر حسب التاريخ
  const sortedMonths = monthlyTotals.sort((a, b) => a.month.localeCompare(b.month));

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6 text-center">
        📊 لوحة الإحصائيات
      </h2>

      {/* إحصائيات عامة */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-6 rounded-lg text-white">
          <div className="text-center">
            <div className="text-3xl mb-2">💰</div>
            <h3 className="text-lg font-semibold">إجمالي المبيعات</h3>
            <p className="text-2xl font-bold">{totalSales.toFixed(2)} ريال</p>
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-500 to-green-600 p-6 rounded-lg text-white">
          <div className="text-center">
            <div className="text-3xl mb-2">👑</div>
            <h3 className="text-lg font-semibold">أعلى عميل</h3>
            <p className="text-lg font-bold">
              {topCustomer ? topCustomer.customer : "لا يوجد"}
            </p>
            {topCustomer && (
              <p className="text-sm opacity-90">{topCustomer.total.toFixed(2)} ريال</p>
            )}
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-500 to-purple-600 p-6 rounded-lg text-white">
          <div className="text-center">
            <div className="text-3xl mb-2">🏆</div>
            <h3 className="text-lg font-semibold">أعلى فاتورة</h3>
            <p className="text-lg font-bold">
              {highestInvoice ? `${highestInvoice.amount.toFixed(2)} ريال` : "لا يوجد"}
            </p>
            {highestInvoice && (
              <p className="text-sm opacity-90">{highestInvoice.customerName}</p>
            )}
          </div>
        </div>
      </div>

      {/* الرسم البياني الشهري */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
        <h3 className="text-xl font-semibold text-gray-800 dark:text-white mb-6 text-center">
          📈 المبيعات الشهرية
        </h3>

        {sortedMonths.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            <div className="text-6xl mb-4">📊</div>
            <p>لا توجد بيانات لعرضها</p>
          </div>
        ) : (
          <div className="space-y-4">
            {sortedMonths.map((month) => {
              const percentage = totalSales > 0 ? (month.total / totalSales) * 100 : 0;
              const monthName = new Date(month.month + '-01').toLocaleDateString('ar-SA', {
                year: 'numeric',
                month: 'long'
              });

              return (
                <div key={month.month} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      {monthName}
                    </span>
                    <span className="text-sm font-bold text-gray-800 dark:text-white">
                      {month.total.toFixed(2)} ريال
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full transition-all duration-500 ease-out"
                      style={{ width: `${Math.max(percentage, 2)}%` }}
                    ></div>
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">
                    {percentage.toFixed(1)}% من إجمالي المبيعات
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* معلومات إضافية */}
      <div className="mt-8 bg-gray-50 dark:bg-gray-700 p-6 rounded-lg">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
          📋 ملخص الإحصائيات
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="space-y-2">
            <p className="text-gray-600 dark:text-gray-300">
              📅 عدد الأشهر النشطة: <span className="font-semibold">{sortedMonths.length}</span>
            </p>
            <p className="text-gray-600 dark:text-gray-300">
              📊 متوسط المبيعات الشهرية: 
              <span className="font-semibold">
                {sortedMonths.length > 0 ? (totalSales / sortedMonths.length).toFixed(2) : '0.00'} ريال
              </span>
            </p>
          </div>
          <div className="space-y-2">
            {sortedMonths.length > 0 && (
              <>
                <p className="text-gray-600 dark:text-gray-300">
                  📈 أعلى شهر: 
                  <span className="font-semibold text-green-600 dark:text-green-400">
                    {new Date(sortedMonths.reduce((max, month) => 
                      month.total > max.total ? month : max
                    ).month + '-01').toLocaleDateString('ar-SA', { month: 'long', year: 'numeric' })}
                  </span>
                </p>
                <p className="text-gray-600 dark:text-gray-300">
                  📉 أقل شهر: 
                  <span className="font-semibold text-red-600 dark:text-red-400">
                    {new Date(sortedMonths.reduce((min, month) => 
                      month.total < min.total ? month : min
                    ).month + '-01').toLocaleDateString('ar-SA', { month: 'long', year: 'numeric' })}
                  </span>
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
